import React from 'react'
import { Layout } from '../components/layout/layout'

export function PageNotFound(){
  return (
    <Layout>
        <h1>page not found</h1>
    </Layout>
  )
}

export default PageNotFound
